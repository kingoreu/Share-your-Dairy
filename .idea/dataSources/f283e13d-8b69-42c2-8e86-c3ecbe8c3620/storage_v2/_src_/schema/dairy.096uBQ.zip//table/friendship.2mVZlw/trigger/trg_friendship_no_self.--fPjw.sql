create definer = root@localhost trigger trg_friendship_no_self
    before insert
    on friendship
    for each row
BEGIN
    IF NEW.user_id = NEW.friend_id THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot be friends with yourself';
    END IF;
END;

